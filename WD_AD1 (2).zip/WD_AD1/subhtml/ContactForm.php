<?php 
if (isset($_POST['submit'])){
    $name=$_POST['name'];
    $phoneNumber=$_POST['phone_number'];
    $mailFrom=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    
    $mailTo="ghungur@srijitasarkar.in";
    $headers="From: ".$mailFrom;
    $txt="you have receive an email from ".$name."\n\n Here is sender phone number ".$phoneNumber."\n\n".$message;
        mail($mailTo,$subject,$txt,$headers);
    header("Location:contact.php?mailsend");
}